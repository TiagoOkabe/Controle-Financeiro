/* Gera a chave SOMENTE se o pagamento estiver aprovado. 1 pagamento = 1 código de dispositivo. */
import {assinar,clean} from "../lib/sign.js";
export async function onRequestPost({request,env}){
  const j=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json"}});
  let b;try{b=await request.json()}catch(_){return j({erro:"Pedido inválido"},400)}
  const id=String(b.id||""),dev=clean(b.device);
  if(!/^\d{5,20}$/.test(id))return j({erro:"Pagamento inválido."},400);
  if(dev.length!==10)return j({erro:"Código do dispositivo inválido. Ele tem 10 letras/números (ex.: 7K3F9-QX2M8)."},400);
  const r=await fetch("https://api.mercadopago.com/v1/payments/"+id,{headers:{Authorization:"Bearer "+env.MP_ACCESS_TOKEN}});
  const p=await r.json();
  if(!r.ok||p.status!=="approved")return j({erro:"Pagamento ainda não confirmado."},402);
  if(!String(p.external_reference||"").startsWith("cf-")||Number(p.transaction_amount)<Number(env.PRECO||19.9))return j({erro:"Pagamento não corresponde ao produto."},403);
  const k="pay:"+id,old=await env.LICENCAS.get(k,"json");
  if(old){
    if(old.dev!==dev)return j({erro:"Este pagamento já gerou uma chave para outro computador. Fale com o suporte no WhatsApp."},409);
    return j({chave:old.chave});
  }
  const chave=await assinar(dev,env.D_PRIVADA);
  await env.LICENCAS.put(k,JSON.stringify({dev,chave,email:p.payer&&p.payer.email,t:Date.now()}));
  return j({chave});
}
