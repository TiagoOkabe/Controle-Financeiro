/* Cria um Pix no Mercado Pago e devolve QR Code + copia e cola */
export async function onRequestPost({request,env}){
  const j=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json"}});
  let b;try{b=await request.json()}catch(_){return j({erro:"Pedido inválido"},400)}
  const email=String(b.email||"").trim();
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return j({erro:"Informe um e-mail válido."},400);
  const r=await fetch("https://api.mercadopago.com/v1/payments",{method:"POST",headers:{
    "Authorization":"Bearer "+env.MP_ACCESS_TOKEN,"Content-Type":"application/json","X-Idempotency-Key":crypto.randomUUID()},
    body:JSON.stringify({transaction_amount:Number(env.PRECO||19.9),description:"Controle Financeiro",payment_method_id:"pix",
      payer:{email},external_reference:"cf-"+crypto.randomUUID()})});
  const d=await r.json();
  if(!r.ok||!d.point_of_interaction)return j({erro:"Não foi possível gerar o Pix agora. Tente de novo."},502);
  const t=d.point_of_interaction.transaction_data;
  return j({id:d.id,qr_code:t.qr_code,qr_base64:t.qr_code_base64});
}
