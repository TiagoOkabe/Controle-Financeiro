/* Consulta se o Pix foi aprovado */
export async function onRequestGet({request,env}){
  const id=new URL(request.url).searchParams.get("id")||"";
  if(!/^\d{5,20}$/.test(id))return new Response('{"erro":"id"}',{status:400});
  const r=await fetch("https://api.mercadopago.com/v1/payments/"+id,{headers:{Authorization:"Bearer "+env.MP_ACCESS_TOKEN}});
  const d=await r.json();
  return new Response(JSON.stringify({status:d.status||"unknown"}),{headers:{"content-type":"application/json"}});
}
